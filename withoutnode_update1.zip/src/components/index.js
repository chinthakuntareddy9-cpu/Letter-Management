export { default as Dashboard } from './Dashboard';
export { default as NewLetter } from './NewLetter';

