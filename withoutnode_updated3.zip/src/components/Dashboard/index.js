export { default } from './Dashboard';
export { default as Dashboard } from './Dashboard';

